﻿using System;
using System.Collections.Generic;
using System.Text;
using Nop.Core.Domain.Orders;

namespace Nop.Plugin.Payments.ManualMollie.Models
{
    public class Identifier
    {
        public string Id { get; set; }
        public DateTime Time { get; set; }

        public Order Order { get; set; }
    }
}
